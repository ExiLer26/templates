package com.durabilityhud.client;

import com.durabilityhud.config.ModConfig;
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.*;
import java.util.ArrayList;
import java.util.List;

public class HudRenderer implements HudRenderCallback {
    
    @Override
    public void onHudRender(GuiGraphics guiGraphics, float tickDelta) {
        if (!ModConfig.ENABLED) return;
        
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;
        
        List<ItemStack> itemsToRender = new ArrayList<>();
        int blockCount = 0;
        ItemStack blockExample = ItemStack.EMPTY;
        
        addPlayerItems(mc, itemsToRender);
        
        if (ModConfig.SHOW_HELD_ITEMS) {
            ItemStack mainHand = mc.player.getMainHandItem();
            if (!mainHand.isEmpty() && !(mainHand.getItem() instanceof BlockItem) && !isAlreadyAdded(itemsToRender, mainHand)) {
                itemsToRender.add(mainHand);
            }
            ItemStack offHand = mc.player.getOffhandItem();
            if (!offHand.isEmpty() && !(offHand.getItem() instanceof BlockItem) && !isAlreadyAdded(itemsToRender, offHand)) {
                itemsToRender.add(offHand);
            }
        }
        
        ItemStack heldItem = mc.player.getMainHandItem();
        if (!heldItem.isEmpty() && heldItem.getItem() instanceof BlockItem) {
            blockExample = heldItem;
            blockCount = countMatchingItems(mc, heldItem);
        }
        
        boolean hasPinnedBlocks = ModConfig.PINNED_BLOCKS_ENABLED && !ModConfig.PINNED_BLOCKS_LIST.isEmpty();
        if (itemsToRender.isEmpty() && blockCount == 0 && !hasPinnedBlocks) return;
        
        int x = ModConfig.HUD_X;
        int y = ModConfig.HUD_Y;
        float scale = (float) ModConfig.HUD_SCALE;
        
        RenderSystem.enableBlend();
        guiGraphics.pose().pushPose();
        guiGraphics.pose().translate(x, y, 0);
        guiGraphics.pose().scale(scale, scale, 1.0f);
        
        int offsetY = 0;
        if (ModConfig.SHOW_BLOCKS && blockCount > 0 && !blockExample.isEmpty()) {
            renderBlockGroup(guiGraphics, mc, blockExample, blockCount, 0, offsetY);
            offsetY += 20;
        }
        for (ItemStack stack : itemsToRender) {
            renderItemWithDurability(guiGraphics, mc, stack, 0, offsetY);
            offsetY += 20;
        }
        
        guiGraphics.pose().popPose();
        RenderSystem.disableBlend();
        renderPinnedBlocks(guiGraphics, mc);
    }
    
    private static void renderPinnedBlocks(GuiGraphics guiGraphics, Minecraft mc) {
        if (!ModConfig.PINNED_BLOCKS_ENABLED) return;
        List<String> pinnedBlocks = ModConfig.PINNED_BLOCKS_LIST;
        if (pinnedBlocks.isEmpty()) return;
        
        int x = ModConfig.PINNED_BLOCKS_X;
        int y = ModConfig.PINNED_BLOCKS_Y;
        float scale = (float) ModConfig.HUD_SCALE;
        
        RenderSystem.enableBlend();
        guiGraphics.pose().pushPose();
        guiGraphics.pose().translate(x, y, 0);
        guiGraphics.pose().scale(scale, scale, 1.0f);
        
        int offsetY = 0;
        for (String blockId : pinnedBlocks) {
            try {
                ResourceLocation location = new ResourceLocation(blockId);
                Item item = BuiltInRegistries.ITEM.get(location);
                if (item != Items.AIR && item instanceof BlockItem) {
                    ItemStack stack = new ItemStack(item);
                    int count = countMatchingItems(mc, stack);
                    renderBlockGroup(guiGraphics, mc, stack, count, 0, offsetY);
                    offsetY += 20;
                }
            } catch (Exception e) {}
        }
        guiGraphics.pose().popPose();
        RenderSystem.disableBlend();
    }
    
    private static boolean isAlreadyAdded(List<ItemStack> items, ItemStack stack) {
        for (ItemStack s : items) {
            if (ItemStack.matches(s, stack)) return true;
        }
        return false;
    }

    private static void addPlayerItems(Minecraft mc, List<ItemStack> items) {
        List<ItemStack> tempItems = new ArrayList<>();
        ItemStack mainHand = mc.player.getMainHandItem();
        if (!mainHand.isEmpty() && mainHand.isDamageableItem() && shouldShowItem(mainHand)) tempItems.add(mainHand);
        ItemStack offHand = mc.player.getOffhandItem();
        if (!offHand.isEmpty() && offHand.isDamageableItem() && shouldShowItem(offHand) && !ItemStack.matches(mainHand, offHand)) tempItems.add(offHand);
        
        for (EquipmentSlot slot : EquipmentSlot.values()) {
            if (slot.getType() == EquipmentSlot.Type.ARMOR) {
                ItemStack armorPiece = mc.player.getItemBySlot(slot);
                if (!armorPiece.isEmpty() && armorPiece.isDamageableItem() && shouldShowItem(armorPiece)) tempItems.add(armorPiece);
            }
        }
        tempItems.sort((a, b) -> Integer.compare(getItemOrder(a), getItemOrder(b)));
        items.addAll(tempItems);
    }
    
    private static int getItemOrder(ItemStack stack) {
        String itemType = getItemType(stack.getItem());
        int index = ModConfig.ITEM_ORDER.indexOf(itemType);
        return index == -1 ? 9999 : index;
    }
    
    private static String getItemType(Item item) {
        if (item instanceof SwordItem) return "sword";
        if (item instanceof PickaxeItem) return "pickaxe";
        if (item instanceof AxeItem) return "axe";
        if (item instanceof ShovelItem) return "shovel";
        if (item instanceof HoeItem) return "hoe";
        if (item instanceof ArmorItem armor) {
            return switch (armor.getType()) {
                case HELMET -> "helmet";
                case CHESTPLATE -> "chestplate";
                case LEGGINGS -> "leggings";
                case BOOTS -> "boots";
                default -> "unknown";
            };
        }
        if (item instanceof ShieldItem) return "shield";
        if (item instanceof ElytraItem) return "elytra";
        if (item instanceof BowItem) return "bow";
        if (item instanceof CrossbowItem) return "crossbow";
        if (item instanceof TridentItem) return "trident";
        if (item instanceof FishingRodItem) return "fishing_rod";
        if (item instanceof ShearsItem) return "shears";
        return "unknown";
    }
    
    private static boolean shouldShowItem(ItemStack stack) {
        Item item = stack.getItem();
        if (item instanceof SwordItem) return ModConfig.SHOW_SWORD;
        if (item instanceof PickaxeItem) return ModConfig.SHOW_PICKAXE;
        if (item instanceof AxeItem) return ModConfig.SHOW_AXE;
        if (item instanceof ShovelItem) return ModConfig.SHOW_SHOVEL;
        if (item instanceof HoeItem) return ModConfig.SHOW_HOE;
        if (item instanceof ArmorItem armor) {
            return switch (armor.getType()) {
                case HELMET -> ModConfig.SHOW_HELMET;
                case CHESTPLATE -> ModConfig.SHOW_CHESTPLATE;
                case LEGGINGS -> ModConfig.SHOW_LEGGINGS;
                case BOOTS -> ModConfig.SHOW_BOOTS;
                default -> true;
            };
        }
        if (item instanceof ShieldItem) return ModConfig.SHOW_SHIELD;
        if (item instanceof ElytraItem) return ModConfig.SHOW_ELYTRA;
        if (item instanceof BowItem) return ModConfig.SHOW_BOW;
        if (item instanceof CrossbowItem) return ModConfig.SHOW_CROSSBOW;
        if (item instanceof TridentItem) return ModConfig.SHOW_TRIDENT;
        if (item instanceof FishingRodItem) return ModConfig.SHOW_FISHING_ROD;
        if (item instanceof ShearsItem) return ModConfig.SHOW_SHEARS;
        return true;
    }
    
    private static int countMatchingItems(Minecraft mc, ItemStack target) {
        int count = 0;
        for (int i = 0; i < mc.player.getInventory().getContainerSize(); i++) {
            ItemStack stack = mc.player.getInventory().getItem(i);
            if (!stack.isEmpty() && ItemStack.isSameItemSameTags(stack, target)) count += stack.getCount();
        }
        return count;
    }
    
    private static void renderBlockGroup(GuiGraphics guiGraphics, Minecraft mc, ItemStack exampleBlock, int totalCount, int x, int y) {
        guiGraphics.renderItem(exampleBlock, x, y);
        String countText = "x" + totalCount;
        int textX = x + 20;
        int textY = y + 4;
        guiGraphics.fill(textX - 1, textY - 1, textX + mc.font.width(countText) + 1, textY + 9, 0x80000000);
        guiGraphics.drawString(mc.font, countText, textX, textY, 0xFFFFFFFF, false);
    }
    
    private static void renderItemWithDurability(GuiGraphics guiGraphics, Minecraft mc, ItemStack stack, int x, int y) {
        guiGraphics.renderItem(stack, x, y);
        if (stack.isEmpty()) return;
        if (stack.isItemEnabled(mc.level.enabledFeatures()) && (stack.isDamageableItem() || stack.isEnchanted())) {
            guiGraphics.renderItemDecorations(mc.font, stack, x, y, "");
        }
        
        if (stack.isDamageableItem()) {
            int maxDamage = stack.getMaxDamage();
            int durability = maxDamage - stack.getDamageValue();
            float durabilityPercent = (float) durability / maxDamage;
            int barColor = durabilityPercent > 0.66f ? 0xFF00FF00 : (durabilityPercent > 0.33f ? 0xFFFFFF00 : 0xFFFF0000);
            String durabilityText = durability + "/" + maxDamage;
            int textX = x + 20;
            int textY = y + 4;
            guiGraphics.fill(textX - 1, textY - 1, textX + mc.font.width(durabilityText) + 1, textY + 9, 0x80000000);
            guiGraphics.drawString(mc.font, durabilityText, textX, textY, barColor, false);
        } else {
            int totalCount = countMatchingItems(mc, stack);
            if (totalCount > 1) {
                String countText = "x" + totalCount;
                int textX = x + 20;
                int textY = y + 4;
                guiGraphics.fill(textX - 1, textY - 1, textX + mc.font.width(countText) + 1, textY + 9, 0x80000000);
                guiGraphics.drawString(mc.font, countText, textX, textY, 0xFFFFFFFF, false);
            }
        }
    }
}
