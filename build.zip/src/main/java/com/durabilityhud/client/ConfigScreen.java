package com.durabilityhud.client;

import com.durabilityhud.config.ModConfig;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class ConfigScreen extends Screen {
    private final Screen parent;
    private ConfigPage currentPage = ConfigPage.MAIN;
    private DraggableButton draggingButton = null;
    private int dragOffsetX = 0;
    private int dragOffsetY = 0;
    private int dragStartIndex = -1;

    private enum ConfigPage {
        MAIN("Ana Sayfa"),
        DURABILITY("Dayanıklılık Ayarları"),
        PINNED_BLOCKS("Sabit Bloklar");
        private final String title;
        ConfigPage(String title) { this.title = title; }
        public String getTitle() { return title; }
    }

    public ConfigScreen(Screen parent) {
        super(Component.literal("Durability HUD Ayarları"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        super.init();
        switch (currentPage) {
            case MAIN -> initMainPage();
            case DURABILITY -> initDurabilityPage();
            case PINNED_BLOCKS -> initPinnedBlocksPage();
        }
        int buttonWidth = 80;
        int spacing = 5;
        int totalWidth = (buttonWidth * 3) + (spacing * 2);
        int startX = (this.width - totalWidth) / 2;
        int tabY = this.height - 30;
        this.addRenderableWidget(Button.builder(Component.literal(ConfigPage.MAIN.getTitle()), b -> switchPage(ConfigPage.MAIN)).bounds(startX, tabY, buttonWidth, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal(ConfigPage.DURABILITY.getTitle()), b -> switchPage(ConfigPage.DURABILITY)).bounds(startX + buttonWidth + spacing, tabY, buttonWidth, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal(ConfigPage.PINNED_BLOCKS.getTitle()), b -> switchPage(ConfigPage.PINNED_BLOCKS)).bounds(startX + (buttonWidth + spacing) * 2, tabY, buttonWidth, 20).build());
    }

    private void initMainPage() {
        int y = 40;
        int buttonWidth = 200;
        int centerX = this.width / 2 - buttonWidth / 2;
        this.addRenderableWidget(Button.builder(Component.literal("HUD Aktif: " + (ModConfig.ENABLED ? "AÇIK" : "KAPALI")), button -> {
            ModConfig.ENABLED = !ModConfig.ENABLED;
            button.setMessage(Component.literal("HUD Aktif: " + (ModConfig.ENABLED ? "AÇIK" : "KAPALI")));
        }).bounds(centerX, y, buttonWidth, 20).build());
        y += 35;
        this.addRenderableWidget(Button.builder(Component.literal("X Pozisyon: " + ModConfig.HUD_X), b -> { ModConfig.HUD_X = (ModConfig.HUD_X + 10 > 1000 ? 0 : ModConfig.HUD_X + 10); rebuildWidgets(); }).bounds(centerX, y, buttonWidth / 2 - 2, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal("-"), b -> { ModConfig.HUD_X = Math.max(0, ModConfig.HUD_X - 10); rebuildWidgets(); }).bounds(centerX + buttonWidth / 2 + 2, y, buttonWidth / 2 - 2, 20).build());
        y += 25;
        this.addRenderableWidget(Button.builder(Component.literal("Y Pozisyon: " + ModConfig.HUD_Y), b -> { ModConfig.HUD_Y = (ModConfig.HUD_Y + 10 > 1000 ? 0 : ModConfig.HUD_Y + 10); rebuildWidgets(); }).bounds(centerX, y, buttonWidth / 2 - 2, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal("-"), b -> { ModConfig.HUD_Y = Math.max(0, ModConfig.HUD_Y - 10); rebuildWidgets(); }).bounds(centerX + buttonWidth / 2 + 2, y, buttonWidth / 2 - 2, 20).build());
        y += 25;
        this.addRenderableWidget(Button.builder(Component.literal("GUI Boyutu: " + String.format("%.1f", ModConfig.HUD_SCALE)), b -> { ModConfig.HUD_SCALE = (ModConfig.HUD_SCALE + 0.1 > 3.0 ? 0.5 : ModConfig.HUD_SCALE + 0.1); rebuildWidgets(); }).bounds(centerX, y, buttonWidth / 2 - 2, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal("-"), b -> { ModConfig.HUD_SCALE = Math.max(0.1, ModConfig.HUD_SCALE - 0.1); rebuildWidgets(); }).bounds(centerX + buttonWidth / 2 + 2, y, buttonWidth / 2 - 2, 20).build());
    }

    private void initDurabilityPage() {
        int y = 40;
        int buttonWidth = 200;
        int centerX = this.width / 2 - buttonWidth / 2;
        this.addRenderableWidget(Button.builder(Component.literal("Hepsini Göster"), b -> { setAllToggles(true); rebuildWidgets(); }).bounds(centerX, y, buttonWidth / 2 - 2, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal("Hepsini Gizle"), b -> { setAllToggles(false); rebuildWidgets(); }).bounds(centerX + buttonWidth / 2 + 2, y, buttonWidth / 2 - 2, 20).build());
        y += 30;
        rebuildDurabilityButtons();
    }

    private void setAllToggles(boolean value) {
        ModConfig.SHOW_BLOCKS = value; ModConfig.SHOW_SWORD = value; ModConfig.SHOW_PICKAXE = value; ModConfig.SHOW_AXE = value; ModConfig.SHOW_SHOVEL = value; ModConfig.SHOW_HOE = value; ModConfig.SHOW_HELMET = value; ModConfig.SHOW_CHESTPLATE = value; ModConfig.SHOW_LEGGINGS = value; ModConfig.SHOW_BOOTS = value; ModConfig.SHOW_SHIELD = value; ModConfig.SHOW_ELYTRA = value; ModConfig.SHOW_BOW = value; ModConfig.SHOW_CROSSBOW = value; ModConfig.SHOW_TRIDENT = value; ModConfig.SHOW_FISHING_ROD = value; ModConfig.SHOW_SHEARS = value; ModConfig.SHOW_HELD_ITEMS = value;
    }

    private void initPinnedBlocksPage() {
        int y = 40;
        int buttonWidth = 200;
        int centerX = this.width / 2 - buttonWidth / 2;
        this.addRenderableWidget(Button.builder(Component.literal("Sabit Bloklar: " + (ModConfig.PINNED_BLOCKS_ENABLED ? "AÇIK" : "KAPALI")), b -> { ModConfig.PINNED_BLOCKS_ENABLED = !ModConfig.PINNED_BLOCKS_ENABLED; rebuildWidgets(); }).bounds(centerX, y, buttonWidth, 20).build());
        y += 35;
        this.addRenderableWidget(Button.builder(Component.literal("Elde Tutulan Bloğu Ekle"), b -> {
            if (this.minecraft != null && this.minecraft.player != null) {
                var heldItem = this.minecraft.player.getMainHandItem();
                if (!heldItem.isEmpty() && heldItem.getItem() instanceof net.minecraft.world.item.BlockItem) {
                    String blockId = net.minecraft.core.registries.BuiltInRegistries.ITEM.getKey(heldItem.getItem()).toString();
                    if (!ModConfig.PINNED_BLOCKS_LIST.contains(blockId)) { ModConfig.PINNED_BLOCKS_LIST.add(blockId); rebuildWidgets(); }
                }
            }
        }).bounds(centerX, y, buttonWidth, 20).build());
        y += 35;
        for (int i = 0; i < ModConfig.PINNED_BLOCKS_LIST.size(); i++) {
            final int index = i; String blockId = ModConfig.PINNED_BLOCKS_LIST.get(i);
            this.addRenderableWidget(Button.builder(Component.literal(blockId.replace("minecraft:", "")), b -> {}).bounds(centerX, y, buttonWidth - 30, 20).build());
            this.addRenderableWidget(Button.builder(Component.literal("X"), b -> { ModConfig.PINNED_BLOCKS_LIST.remove(index); rebuildWidgets(); }).bounds(centerX + buttonWidth - 25, y, 25, 20).build());
            y += 25;
        }
    }

    private void switchPage(ConfigPage page) { this.currentPage = page; rebuildWidgets(); }

    private void rebuildDurabilityButtons() {
        int y = 70; int centerX = this.width / 2 - 100;
        for (int i = 0; i < ModConfig.ITEM_ORDER.size(); i++) {
            String key = ModConfig.ITEM_ORDER.get(i);
            addDraggableItemToggle(key, i, centerX, y);
            y += 25;
        }
    }

    private void addDraggableItemToggle(String itemKey, int index, int x, int y) {
        Map<String, String> labels = new HashMap<>();
        labels.put("blocks", "Bloklar (Elde)"); labels.put("sword", "Kılıç"); labels.put("pickaxe", "Kazma"); labels.put("axe", "Balta"); labels.put("shovel", "Kürek"); labels.put("hoe", "Çapa"); labels.put("helmet", "Miğfer"); labels.put("chestplate", "Göğüslük"); labels.put("leggings", "Pantolon"); labels.put("boots", "Çizme"); labels.put("shield", "Kalkan"); labels.put("elytra", "Elytra"); labels.put("bow", "Yay"); labels.put("crossbow", "Tatar Yayı"); labels.put("trident", "Üç Dişli Mızrak"); labels.put("fishing_rod", "Olta"); labels.put("shears", "Makas"); labels.put("held_items", "Elde Tutulanlar");
        this.addRenderableWidget(new DraggableButton(x, y, 200, 20, labels.getOrDefault(itemKey, itemKey), itemKey, index));
    }

    @Override public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) { this.renderBackground(guiGraphics); guiGraphics.drawCenteredString(this.font, currentPage.getTitle(), this.width / 2, 15, 0xFFFFFF); super.render(guiGraphics, mouseX, mouseY, partialTick); }
    @Override public void onClose() { if (this.minecraft != null) this.minecraft.setScreen(this.parent); }

    private class DraggableButton extends Button {
        private final String itemKey;
        private final int originalIndex;
        public DraggableButton(int x, int y, int w, int h, String label, String key, int idx) {
            super(x, y, w, h, Component.literal(label + ": " + (getConfigValue(key) ? "GÖSTER" : "GİZLE")), b -> { toggleConfigValue(key); b.setMessage(Component.literal(label + ": " + (getConfigValue(key) ? "GÖSTER" : "GİZLE"))); }, DEFAULT_NARRATION);
            this.itemKey = key; this.originalIndex = idx;
        }
        private boolean getConfigValue(String key) {
            return switch (key) {
                case "blocks" -> ModConfig.SHOW_BLOCKS; case "sword" -> ModConfig.SHOW_SWORD; case "pickaxe" -> ModConfig.SHOW_PICKAXE; case "axe" -> ModConfig.SHOW_AXE; case "shovel" -> ModConfig.SHOW_SHOVEL; case "hoe" -> ModConfig.SHOW_HOE; case "helmet" -> ModConfig.SHOW_HELMET; case "chestplate" -> ModConfig.SHOW_CHESTPLATE; case "leggings" -> ModConfig.SHOW_LEGGINGS; case "boots" -> ModConfig.SHOW_BOOTS; case "shield" -> ModConfig.SHOW_SHIELD; case "elytra" -> ModConfig.SHOW_ELYTRA; case "bow" -> ModConfig.SHOW_BOW; case "crossbow" -> ModConfig.SHOW_CROSSBOW; case "trident" -> ModConfig.SHOW_TRIDENT; case "fishing_rod" -> ModConfig.SHOW_FISHING_ROD; case "shears" -> ModConfig.SHOW_SHEARS; case "held_items" -> ModConfig.SHOW_HELD_ITEMS; default -> true;
            };
        }
        private void toggleConfigValue(String key) {
            switch (key) {
                case "blocks" -> ModConfig.SHOW_BLOCKS = !ModConfig.SHOW_BLOCKS; case "sword" -> ModConfig.SHOW_SWORD = !ModConfig.SHOW_SWORD; case "pickaxe" -> ModConfig.SHOW_PICKAXE = !ModConfig.SHOW_PICKAXE; case "axe" -> ModConfig.SHOW_AXE = !ModConfig.SHOW_AXE; case "shovel" -> ModConfig.SHOW_SHOVEL = !ModConfig.SHOW_SHOVEL; case "hoe" -> ModConfig.SHOW_HOE = !ModConfig.SHOW_HOE; case "helmet" -> ModConfig.SHOW_HELMET = !ModConfig.SHOW_HELMET; case "chestplate" -> ModConfig.SHOW_CHESTPLATE = !ModConfig.SHOW_CHESTPLATE; case "leggings" -> ModConfig.SHOW_LEGGINGS = !ModConfig.SHOW_LEGGINGS; case "boots" -> ModConfig.SHOW_BOOTS = !ModConfig.SHOW_BOOTS; case "shield" -> ModConfig.SHOW_SHIELD = !ModConfig.SHOW_SHIELD; case "elytra" -> ModConfig.SHOW_ELYTRA = !ModConfig.SHOW_ELYTRA; case "bow" -> ModConfig.SHOW_BOW = !ModConfig.SHOW_BOW; case "crossbow" -> ModConfig.SHOW_CROSSBOW = !ModConfig.SHOW_CROSSBOW; case "trident" -> ModConfig.SHOW_TRIDENT = !ModConfig.SHOW_TRIDENT; case "fishing_rod" -> ModConfig.SHOW_FISHING_ROD = !ModConfig.SHOW_FISHING_ROD; case "shears" -> ModConfig.SHOW_SHEARS = !ModConfig.SHOW_SHEARS; case "held_items" -> ModConfig.SHOW_HELD_ITEMS = !ModConfig.SHOW_HELD_ITEMS;
            }
        }
    }
}
