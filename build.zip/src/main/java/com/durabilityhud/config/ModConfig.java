package com.durabilityhud.config;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ModConfig {
    public static boolean ENABLED = true;
    public static int HUD_X = 10;
    public static int HUD_Y = 10;
    public static double HUD_SCALE = 1.0;
    
    public static boolean PINNED_BLOCKS_ENABLED = true;
    public static int PINNED_BLOCKS_X = 10;
    public static int PINNED_BLOCKS_Y = 100;
    public static List<String> PINNED_BLOCKS_LIST = new ArrayList<>();
    
    public static List<String> ITEM_ORDER = new ArrayList<>(Arrays.asList(
        "blocks", "sword", "pickaxe", "axe", "shovel", "hoe",
        "helmet", "chestplate", "leggings", "boots", "shield",
        "elytra", "bow", "crossbow", "trident", "fishing_rod", "shears", "held_items"
    ));
    
    public static List<Integer> ITEM_POS_X = new ArrayList<>();
    public static List<Integer> ITEM_POS_Y = new ArrayList<>();
    
    public static boolean SHOW_BLOCKS = true;
    public static boolean SHOW_SWORD = true;
    public static boolean SHOW_PICKAXE = true;
    public static boolean SHOW_AXE = true;
    public static boolean SHOW_SHOVEL = true;
    public static boolean SHOW_HOE = true;
    public static boolean SHOW_HELMET = true;
    public static boolean SHOW_CHESTPLATE = true;
    public static boolean SHOW_LEGGINGS = true;
    public static boolean SHOW_BOOTS = true;
    public static boolean SHOW_SHIELD = true;
    public static boolean SHOW_ELYTRA = true;
    public static boolean SHOW_BOW = true;
    public static boolean SHOW_CROSSBOW = true;
    public static boolean SHOW_TRIDENT = true;
    public static boolean SHOW_FISHING_ROD = true;
    public static boolean SHOW_SHEARS = true;
    public static boolean SHOW_HELD_ITEMS = true;

    public static void register() {
    }
    
    public static void save() {
    }
}
